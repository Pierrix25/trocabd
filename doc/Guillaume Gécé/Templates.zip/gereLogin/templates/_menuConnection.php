
<!--  custom menu connection -->
<?php if (!$sf_user->isAuthenticated()): ?>
	<?php echo form_tag('gereLogin/login') ?>
<div class="roundedcornr_box_508182">
   <div class="roundedcornr_top_508182"><div></div></div>
      <div class="roundedcornr_content_508182">
		<table>
		<tr>
		<td>
		Identifiant :
		</td>
		<td align=right>
		<?php echo input_tag ('identifiant', $login, 'onfocus="if (this.value == \'votre identifiant\') this.value=\'\'" size="15"') ?>
		</td>
		</tr>
		<tr>
		<td>
		Mot de passe :
		</td>
		<td align=right>
		<?php echo input_password_tag ('motDePasse', $pwd, 'onfocus="if (this.value == \'votre mot de passe\') this.value=\'\'" size="15"') ?>
		</tr>
		<tr>
		<td align=right colspan ="2">
		<?php echo submit_image_tag ('bouton_go.gif') ?>
		</td>
		</tr>
		</table>
		<?php echo $message ?>
		<?php if (!($sf_request->getContext()->getModuleName().'/'.$sf_request->getContext()->getActionName()=='gereUtilisateur/create')):?>
 	 		<?php echo link_to('Inscrivez-vous', 'gereUtilisateur/create') ?>
 	 		<?php echo link_to('Mot de passe oubi�', 'gereOublie/edit') ?>
		<?php endif; ?>
      </div>
   <div class="roundedcornr_bottom_508182"><div></div></div>
</div>		
		</form>
<?php else: ?>
  	<p><?php echo link_to(' D�connexion', 'gereLogin/logout') ?></p>
  	<p></p>
<?php endif; ?>
