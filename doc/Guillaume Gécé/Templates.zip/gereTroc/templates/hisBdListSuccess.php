<?php include_partial('bdList', array('utilid' => $sf_request->getParameter('utilid'), 'list' => 'his', 'thePager' => $hisPager, 'contexte' => 'SonOffre', 'vitrine' => 'saVitrine')) ?>
