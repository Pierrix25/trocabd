<?php include_partial('offreList', array('liste' => $sonOffre, 'contexte' => 'SonOffre')) ?>
