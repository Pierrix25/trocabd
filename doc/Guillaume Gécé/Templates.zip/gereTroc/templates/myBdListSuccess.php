<?php include_partial('bdList', array('utilid' => $sf_request->getParameter('utilid'), 'list' => 'my', 'thePager' => $myPager, 'contexte' => 'MonOffre', 'vitrine' => 'maVitrine')) ?>
