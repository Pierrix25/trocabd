<tr><td>Nom :</td><td><?php echo $user->getNom() ?></td></tr>
<tr><td>Pr�nom :</td><td><?php echo $user->getPrenom() ?></td></tr>
<tr><td>Adresse :</td><td><?php echo $user->getRue2() ?></td></tr>
<tr><td> </td><td><?php echo $user->getRue3() ?></td></tr>
<tr><td> </td><td><?php echo $user->getRue4() ?></td></tr>
<tr><td>Code postal :</td><td><?php echo $user->getCP() ?></td></tr>
<tr><td>Ville :</td><td><?php echo $user->getVille() ?></td></tr>
<tr><td>Email :</td><td><?php echo $user->getEmail() ?></td></tr>
