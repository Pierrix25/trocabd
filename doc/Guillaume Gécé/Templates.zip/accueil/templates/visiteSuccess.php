<table>
<tr>
    <td valign="top" colspan="5" align="left">
	<font color="#FF0000" size="5"><b>Bienvenue sur le site de 
	Troc de Bandes&nbsp; Dessin�es,</b></font></td></tr>
	<tr></tr>
	<tr><td colspan="4" align="left">
	<b><font size="5" color="#FF6600">Visitez, consulter le catalogue de BD en cliquant <?php echo link_to('ici', 'gereBD/recherche?sort=Talbum&filtrePossede=N')?></font></b></td>
	<td rowspan="5">
<?php $map->printHeaderJS(); ?>
<?php $map->printMapJS(); ?>

		<?php $map->printMap(); ?>
	</td>
	</tr>
	<tr><td></td><td colspan="2" align="left">
	<b><font size="7" color="#66CC33">Inscrivez-vous, </font></b><?php echo link_to('aide', 'http://localhost/demoInitCompte.html', 'popup=true')?></td></tr>
	<tr><td colspan="3" align="left">
	<b><font size="9" color="#FF6600">Cr�ez votre vitrine, </font></b><?php echo link_to('aide', 'http://localhost/demoInitVitrine.html', 'popup=true')?></td></tr>
	<tr><td colspan="1"></td><td colspan="3" align="left">
	<b><font size="11" color="#3333CC">Recherchez, </font></b></td></tr>
	<tr><td colspan="2"></td><td align="left">
	<b><font size="20" color="#FF0000">Troquez !!! </font></b><?php echo link_to('aide', 'http://localhost/demoTroc.html', 'popup=true')?></td></tr>
  <tr>
    <td valign="top" colspan="5">
    	<BR><p align="left"><b><font color="#FF6600" size="5">Dernier troqueur inscrit : <font size="5"><?php echo $lastUser->getLogin()?></font>
	le <?php echo $lastUser->getCreatedAt()?>
	</font></b>
    	<BR><p align="left"><b><font color="#FF6600" size="5">Dernier visite de troqueur : <font size="5"><?php echo $lastConnectedUser->getLogin()?></font>
	le <?php echo $lastConnectedUser->getDerniereConnexion()?>
	</font></b>
	</td>
  </tr>
  </table>


