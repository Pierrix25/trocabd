<table>
<tr>
    <td valign="top" colspan="2">
	<br><br><br><p align="center"><font color="#FF0000" size="5"><b>Bienvenue sur votre espace perso</b></font></p><br>
	<b><font size="5" color="#FF6600">    consulter le catalogue de BD en cliquant <?php echo link_to('ici', 'gereBD/recherche?sort=Talbum&filtrePossede=N')?></font></b></td></tr>
  <tr>
    <td valign="top" >
</td>
    <td valign="top" >
</td>
  </tr>
  <tr>
    <td valign="top" >
    <?php $map->printHeaderJS(); ?>
<?php $map->printMapJS(); ?>

		<?php $map->printMap(); ?>
    </td>
    <td valign="top" ></td>
  </tr>
  </table>


